import './App.css';
import PasswordGenerator from './Components/PasswordGenerator/PasswordGenerator';

function App() {
  return (
    <>
      <PasswordGenerator />
    </>
  );
}

export default App;
